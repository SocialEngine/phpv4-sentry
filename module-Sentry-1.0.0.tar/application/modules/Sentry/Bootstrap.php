<?php
/**
 * SocialEngine
 *
 * @category   Module_Sentry
 * @package    Sentry
 * @copyright  Copyright 2006-2017 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */

/**
 * Class Sentry_Bootstrap
 *
 * @codingStandardsIgnoreStart
 */
class Sentry_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
    // @codingStandardsIgnoreEnd
}
