<?php

/**
 * Class Sentry_Installer
 *
 * @codingStandardsIgnoreStart
 */
class Sentry_Installer extends Engine_Package_Installer_Module
{
    // @codingStandardsIgnoreEnd

    public function onInstall()
    {
        parent::onInstall();
    }
}
